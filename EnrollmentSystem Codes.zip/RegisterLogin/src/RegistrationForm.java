import com.mysql.cj.xdevapi.Result;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class RegistrationForm extends JDialog {
    private JTextField tfUsername;
    private JTextField tfEmail;
    private JTextField pfPassword;
    private JButton btnCancel;
    private JButton btnRegister;
    private JPanel registerPanel;

    public RegistrationForm(JFrame parent) {
        super(parent);
        setTitle("create a new account");
        setContentPane(registerPanel);
        setMinimumSize(new Dimension(455, 475));
        setModal(true);
        setLocationRelativeTo(parent);
        SetDefaultCloserOperation(DISPOSE_ON_CLOSE);


        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void SetDefaultCloserOperation(int disposeOnClose) {
    }

    private void registerUser() {
        String username = tfUsername.getText();
        String email = tfEmail.getText();
        String password = String.valueOf(pfPassword.getText());

        username = "";
        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog( this,
                    "Please enter all fields",
                    "Try Again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

       user = addUserToDatabase(username, email, password);
        if (user != null) {
            dispose();
        }
        else {
            JOptionPane.showMessageDialog( this,
                    "Failed to register new user",
                            "Try again",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
public User user;
    private User addUserToDatabase(String Username, String email, String password) {
        User User = null;

        final String DB_URL = "jdbc:mysql://localhost/enrollmentsystem?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...

            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO users (username, email, password) " +
                    "VALUES (?, ?, ?,)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, Username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, password);

           //Insert row into the table
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                user = new User();
                user.username = Username;
                user.email = email;
                user.password = password;
            }

            stmt.close();
            conn.close();
        }catch (Exception e){
            e.printStackTrace();

        }


        return user;
    }

    public static void main(String[] args) {
        JFrame parent = null;
        RegistrationForm myForm = new RegistrationForm (null);
        User user = myForm.user;
        if (user != null) {
            System.out.println("Successful registration of: " + user.username);
        }
        else{
            System.out.println("Registration canceled");
        }
    }
}
