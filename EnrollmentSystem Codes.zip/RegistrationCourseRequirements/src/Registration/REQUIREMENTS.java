package Registration;

import javax.swing.*;

public class REQUIREMENTS {

    public void displaymessage(){

        System.out.println("Message from requirements");
    }
}
