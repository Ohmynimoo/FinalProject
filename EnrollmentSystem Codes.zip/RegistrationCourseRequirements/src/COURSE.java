import javax.swing.*;

public class COURSE {

    public void displaymessage(){

        System.out.println("Message from course");
    }
}
